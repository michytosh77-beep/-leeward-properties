const menuButton = document.querySelector(".menu-toggle");
const nav = document.querySelector(".nav");
menuButton.addEventListener("click", () => {
  const isOpen = nav.classList.toggle("open");
  menuButton.setAttribute("aria-expanded", String(isOpen));
});
document.querySelectorAll(".nav a").forEach(link => link.addEventListener("click", () => {
  nav.classList.remove("open");
  menuButton.setAttribute("aria-expanded", "false");
}));

document.querySelectorAll(".filter").forEach(button => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".filter").forEach(item => item.classList.remove("active"));
    button.classList.add("active");
    const filter = button.dataset.filter;
    document.querySelectorAll(".property-card").forEach(card => {
      card.classList.toggle("hidden", filter !== "all" && card.dataset.category !== filter);
    });
  });
});

const whatsappNumber = "2348065305104";
document.querySelectorAll(".enquire").forEach(link => {
  link.addEventListener("click", event => {
    event.preventDefault();
    const title = link.closest(".property-card").querySelector("h3").textContent;
    const message = `Hello OLUWOLE OMOTOSHO & CO, I would like to make an enquiry about: ${title}. Please share your available listings and details.`;
    window.open(`https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`, "_blank", "noopener");
  });
});

document.getElementById("contactForm").addEventListener("submit", event => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const message = [
    "Hello OLUWOLE OMOTOSHO & CO,",
    `My name is ${form.get("name")}.`,
    `Email: ${form.get("email")}.`,
    `Enquiry: ${form.get("interest")}.`,
    `Message: ${form.get("message")}`
  ].join("\n");
  window.open(`https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`, "_blank", "noopener");
});
document.getElementById("year").textContent = new Date().getFullYear();
