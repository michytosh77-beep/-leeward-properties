# OLUWOLE OMOTOSHO & CO — Property Marketing Website

A responsive static website for a real estate and property consultancy. It uses plain HTML, CSS and JavaScript, so it does not require a paid framework, database or hosting plan.

## Included
- Home page and company introduction
- Property portfolio categories with working filters
- Services: sales, rentals, valuation, management, short lets and commercial properties
- Contact form that prepares an enquiry in WhatsApp
- Click-to-call, email and WhatsApp links
- Responsive mobile navigation
- SEO title and description

## Before publishing
1. Confirm the office address and replace `To be confirmed` in `index.html`.
2. Check the phone number and email in `index.html`.
3. Replace the sample property category cards with real listings, prices, locations and photos. The current cards are category placeholders, not live listings.
4. Replace the stock photos with photos you own or have permission to use.
5. If the WhatsApp number changes, update `whatsappNumber` in `script.js` and the `wa.me` links in `index.html`.

## Preview on your computer
Unzip the folder and double-click `index.html`. An internet connection is needed for Google Fonts and the remote sample photos.

## Publish free with GitHub and Vercel
### GitHub
1. Sign in at https://github.com and create a new repository, for example `oluwole-omotosho-property-website`.
2. Upload `index.html`, `styles.css`, `script.js` and `README.md` from this folder to the repository root.
3. Commit the files.

### Vercel
1. Sign in at https://vercel.com using GitHub.
2. Choose **Add New → Project** and import the repository you just created.
3. For a plain static website, leave the framework preset as **Other**. No build command is needed. Leave the output directory blank or set it to `.` if prompted.
4. Deploy. Vercel will provide a free `*.vercel.app` address.

You can redeploy by committing later edits to the GitHub repository. Free-plan terms and limits are set by GitHub and Vercel and may change.

## Important
This project is a front-end marketing website. It does not yet include an admin dashboard, database, property upload system or automated email delivery. For now, edit the property cards directly in `index.html`; enquiries open WhatsApp for the visitor to send.
